export const base_url = 'http://localhost:1456';
// export const base_url = "http://test.poletalks.com"; //test server
// export const base_url = "https://app.poletalks.com"; //production

// export const app_url = "http://localhost:3000";
export const app_url = "https://test.poletalks.com"; //test server
// export const app_url = "https://poletalks.com"; //production server

export const appPages = {
	HOME: "home",
	ABOUT: "about"
};
