import React, { Component } from 'react';
import Flexbox from 'flexbox-react';
import { ButtonToolbar, Button } from 'react-bootstrap';
import { Navbar, Nav, NavItem, NavDropdown, MenuItem } from 'react-bootstrap';

import NavLink from './components/_navlinks.js';
// import './css/page1.less';
import './css/main_home.less';
import Page1a from './page1a';

class MainHome extends Component {
    render() {
        return (
            <div className="fluid-container">
                <Flexbox flexDirection="row" minWidth="100vw" className="AppHeader simple from-right transition-item">
                    <Navbar className="minHeight" collapseOnSelect>
                        <Navbar.Header >
                            <Navbar.Brand>
                                <NavLink className="logo" to="/">
                                    <img src="../assets/images/logo.png " className="img-responsive margin-top-bottom" />
                                </NavLink>
                            </Navbar.Brand>
                            <Navbar.Toggle />
                        </Navbar.Header>
                        <Navbar.Collapse>
                            <Nav pullRight>
                                <NavLink className="home" to="/">
                                    Home
                                </NavLink>
                                <NavLink className="home" to="/">
                                    Sign In
                                </NavLink>
                                <NavLink className="home" to="/">
                                    Sign Up
                                </NavLink>
                                {/* <NavDropdown eventKey={1} title="Home" id="dropdown1">
                                    <NavLink withLi to="/page1/a">A</NavLink>
                                    <NavLink withLi to="/page1/b">B</NavLink>
                                </NavDropdown>
                                <NavDropdown eventKey={2} title="Sign In " id="dropdown2">
                                    <NavLink withLi to="/page2/a">A</NavLink>
                                    <NavLink withLi to="/page2/b">B</NavLink>
                                </NavDropdown> */}
                            </Nav>
                        </Navbar.Collapse>
                    </Navbar>
                </Flexbox>
                <div className="col-xs-12 col-md-12 section startupPortal">
                    <div className="col-xs-12 col-md-10 col-md-offset-1">
                        <div className=" col-xs-12 col-md-12 portal">
                            <h1> Startup Ecosystem Portal </h1>
                            <p  >{"This is a paragraph, lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the  industry's standard dummy text ever since the 1500s. "}</p>
                        </div>
                        <div className="col-xs-12 col-md-12 chooseStartup">
                            <div className="col-md-3 col-md-offset-1 decription">

                                <h3>
                                    <img src="../assets/images/startup .png" alt=" not defined"></img> For Startup </h3>
                                <p>Build a profile and share it with investors to get funding.</p>

                            </div>
                            <div className=" col-md-3 col-md-offset-1 decription">

                                <h3> <img src="../assets/images/growth-1 .png" alt=" not defined"></img>For Investor </h3>

                                <p> Access powerful deal flow management tools on a secure platform.</p>

                            </div>
                            <div className=" col-md-3 col-md-offset-1 decription">

                                <h3><img src="../assets/images/speedometer .png" alt=" not defined"></img> For Accelators </h3>

                                <p>  Increase applications, manage the application process, and make your cohorts happy.</p>

                            </div>
                        </div>
                        <div className="col-xs-12 col-md-8 col-md-offset-2  chooseStartup2">
                            <div className=" description">

                                <h3> <img src="../assets/images/brainstorming.png" alt=" not defined"></img> For Talents </h3>

                                <p>  Apply privately to 66,932 startup jobs with one application. No middlemen · See salary and equity upfront.</p>

                            </div>
                            <div className="  description">

                                <h3> <img src="../assets/images/handshake1.png" alt="not defined"></img> For Markets </h3>

                                <p>   An Indian e-portal that provides B2C, B2B and customer to customer sales services via web portal.</p>

                            </div>

                        </div>

                    </div>
                </div>

                <div className="col-xs-12 col-md-12 section featureDetailContainer">
                    <div className="col-xs-12 col-md-10 col-md-offset-1">
                        <div className="col-xs-12 col-md-12 textDetailsContainer">
                            All the features details
                </div>
                        <div className="col-xs-12 col-md-12 imageDetailsContainer">

                            <div className="col-xs-12 col-md-12 columnAlign">
                                <div className="  image1">
                                    <img src="../assets/images/search.png" alt="not found"></img>
                                </div>
                                <div className=" text">
                                    <h5> Search</h5>
                                    <p> hii hello iCreate </p>

                                </div>
                                {/* <div className="  defineText"><p> hello  icreate  website </p>

                                </div> */}
                            </div>

                            <div className=" col-xs-12 columnAlign">
                                <div className="  image2">
                                    <img src="../assets/images/post.png" alt="not found"></img>
                                </div>
                                <div className="text">
                                    <h5> post</h5>
                                    <p> hii hello iCreate </p>
                                </div>

                            </div>

                            <div className="col-xs-12  columnAlign">
                                <div className="  image3">
                                    <img src="../assets/images/chat.png" alt=" not found"></img>
                                </div>
                                <div className="  text">
                                    <h5> chat </h5>
                                    <p> hii hello iCreate </p>
                                </div>




                            </div>
                        </div>
                    </div>
                </div>

                <div className="col-xs-12 col-md-12 section aboutIcreate">

                    <div className="col-xs-12 col-md-10 col-md-offset-1 mainSubIcreate">
                        <div className="col-xs-12 col-md-4 subAboutIcreate">
                            <div className="col-xs-12 icreateMission child1">
                                <h2> Mission </h2>
                                <p> icreate is an independent centre and facilitates "Next Generation Entrepreneurship" that blends creativity,
                            innovation, engineering, product design and leverages emerging technologies to evolve out-of-the-box
                            applications.
                        </p>
                            </div>
                            <div className="col-xs-12 icreateMission child2">
                                <h2> Vision </h2>
                                <p> icreate is an independent centre and facilitates "Next Generation Entrepreneurship" that blends creativity,
                            innovation, engineering, product design and leverages emerging technologies to evolve out-of-the-box
                            applications.
                        </p>
                            </div>
                        </div>
                        <div className="col-xs-12 col-md-8 logoDivision">
                            <div className="icreateLogo">
                                <img src="../assets/images/icreate.png" alt=" not found "></img>
                            </div>
                        </div>
                    </div>

                </div>

                <div className="col-md-12 section">
                    <div className="col-xs-12 col-md-6 col-md-offset-3">
                        <ul>
                            <li ><img src="../assets/images/sstar.png" alt=" not defined "></img>Basecamp</li>
                            <li ><img src="../assets/images/sstar.png" alt=" not defined "></img>grubHub</li>
                            <li ><img src="../assets/images/sstar.png" alt="not defined "></img>Trello</li>
                            <li ><img src="../assets/images/sstar.png" alt=" not defined "></img>buffer</li>
                            <li ><img src="../assets/images/sstar.png" alt=" not defined "></img>pocket</li>
                        </ul>
                    </div>
                </div>

                <div className="col-xs-12 col-md-12 section deliverHappiness">
                    <div className="col-xs-12 col-md-10 col-md-offset-1">
                        <div className="col-xs-12 col-md-12 happinesstext">
                            <h2> Great Products Deliver Happiness to Users</h2>
                        </div>
                        <div className="col-xs-12 col-md-12 " style={{ textAlign: "center" }}>
                            <button type="button " className="btn btn-secondary auto-lr-margin" style={{ backgroundColor: "#57b751", color: "white" }} >Get Started</button>
                        </div>
                    </div>
                </div>


            </div >
        )
    }
}

export default MainHome;


// WEBPACK FOOTER //
// src/pages/main_home.js